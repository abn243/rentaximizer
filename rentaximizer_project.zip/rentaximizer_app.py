
import streamlit as st
import pandas as pd
import numpy as np
import io

st.set_page_config(page_title="RentaXimizer", layout="wide")

st.title("📊 Simulateur de rentabilité immobilière - RentaXimizer")

st.sidebar.header("Paramètres du projet")

# Paramètres d'investissement
prix_bien = st.sidebar.number_input("Prix du bien (€)", value=200000)
frais_notaire = st.sidebar.number_input("Frais de notaire (€)", value=16000)
travaux = st.sidebar.number_input("Travaux (€)", value=30000)
ameublement = st.sidebar.number_input("Ameublement (€)", value=8000)
apport = st.sidebar.number_input("Apport personnel (€)", value=20000)

# Paramètres de crédit
st.sidebar.subheader("Crédit")
taux_credit = st.sidebar.number_input("Taux du crédit (%)", value=3.5)
duree_credit = st.sidebar.number_input("Durée du crédit (années)", value=20)

# Paramètres de loyer et charges
st.sidebar.subheader("Revenus & Charges")
loyer_mensuel = st.sidebar.number_input("Loyer mensuel (€)", value=900)
charges_copro = st.sidebar.number_input("Charges de copropriété annuelles (€)", value=1200)
assurance = st.sidebar.number_input("Assurance PNO (€)", value=150)
taxe_fonciere = st.sidebar.number_input("Taxe foncière (€)", value=1000)
autres_charges = st.sidebar.number_input("Autres charges annuelles (€)", value=500)

# Calculs
montant_emprunt = prix_bien + frais_notaire + travaux + ameublement - apport
mensualite = npf.pmt(taux_credit / 100 / 12, duree_credit * 12, -montant_emprunt)
revenu_annuel = loyer_mensuel * 12
charges_annuelles = charges_copro + assurance + taxe_fonciere + autres_charges + mensualite * 12
cashflow_annuel = revenu_annuel - charges_annuelles

# Affichage des résultats
st.subheader("Résultats de la simulation")
col1, col2, col3 = st.columns(3)
col1.metric("Montant emprunté", f"{montant_emprunt:,.0f} €")
col2.metric("Mensualité de crédit", f"{mensualite:,.0f} €")
col3.metric("Cashflow annuel", f"{cashflow_annuel:,.0f} €")

# Export des résultats
df_export = pd.DataFrame({
    "Type": ["Montant emprunté", "Mensualité", "Revenu annuel", "Charges", "Cashflow"],
    "Valeur (€)": [montant_emprunt, mensualite, revenu_annuel, charges_annuelles, cashflow_annuel]
})

@st.cache_data
def convert_df(df):
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine='xlsxwriter') as writer:
        df.to_excel(writer, index=False)
    return buffer.getvalue()

excel_data = convert_df(df_export)
st.download_button("📥 Télécharger les résultats (Excel)", data=excel_data, file_name="rentaximizer_resultats.xlsx")
